﻿using Formulator;
using Xamarin.Forms.Xaml;

namespace $rootnamespace$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class $safeitemname$ : ContentPage<$safeitemname$ViewModel>
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}